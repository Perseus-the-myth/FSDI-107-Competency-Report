import "./product.css";
import QuantityPicker from "./quantityPicker";
const Product = (props) => {
  const handleQuantityChange = (val) => {
    console.log("QP changed", val);
  };

  return (
    <div className="product">
      <label className="prod-category">{props.info.category}</label>
      <img src={"/images/" + props.info.image} alt="product"></img>
      <h2>{props.info.title}</h2>
      <div>
        <label className="total">$Total</label>
        <label className="price">${props.info.price}</label>
      </div>

      <QuantityPicker onChange={handleQuantityChange}></QuantityPicker>
      <button className="btn-add btn btn-sm btn-primary">Add</button>
      <i className="fa fa-cart-plus" aria-hidden="true"></i>
    </div>
  );
};

export default Product;
