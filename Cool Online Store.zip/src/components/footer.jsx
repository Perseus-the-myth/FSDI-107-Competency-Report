import "./footer.css";

const Footer = () =>{
    return (

    <div className="footer">
        <h4>Cool Store 2021. All rights reserved</h4>
        <h4>Michael Mckitrick</h4>
    </div>
    );


}
export default Footer;