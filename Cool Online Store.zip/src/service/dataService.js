var catalog = [
  {
    _id: "1o2lks",
    title: "Sunglasses",
    price: "20.00",
    stock: "50",
    image: "Aviator glasses.jpeg",
    category: "Apperal",
  },
  {
    _id: "y123iuyoh",
    title: "jackets",
    price: "100.00",
    stock: "20",
    image: "jacket.jpeg",
    category: "Apperal",
  },

  {
    _id: "08fjjefe",
    title: "friges",
    price: "200.00",
    stock: "30",
    image: "Fridges.jpeg",
    category: "Appliances",
  },
  {
    _id: "98j435g",
    title: "sweatshirts",
    price: "50.00",
    stock: "30",
    image: "sweat shirts.jpeg",
    category: "Apperal",
  },
  {
    _id: "iopf663",
    title: "air conditioners",
    price: "100.00",
    stock: "50",
    image: "Air Conditioners.jpeg",
    category: "Appliances",
  },
  {
    _id: "568rdgr",
    title: "ice cube trays",
    price: "10.00",
    stock: "50",
    image: "ice cube tray.jpeg",
    category: "Appliances",
  },
];

class DataService {
  getCatalog() {
    //connect server
    //retrieve the catalog
    //return mock data

    return catalog;
  }
}

export default DataService;
